﻿using System;

namespace Project_C_Big_boss
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab02 lab = new Lab02();
        }
    }
}
