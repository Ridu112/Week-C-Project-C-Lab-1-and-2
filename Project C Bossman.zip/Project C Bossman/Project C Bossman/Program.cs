﻿using System;

namespace Project_C_Bossman
{
    class Program
    {
        static void Main(string[] args)
        {
            Lab01 lab = new Lab01();
        }
    }
}
